--
-- PostgreSQL database dump
--

\restrict UZ76bgufxMXsamTvSsPoafwB6XujW12gY8kkFaUCl1pB0Skml2zAioNIVTmkW5R

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: venrides_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO venrides_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: venrides_user
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chat_threads; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.chat_threads (
    id integer NOT NULL,
    gmail_thread_id character varying,
    participant_1_id integer,
    participant_2_id integer,
    last_message_at timestamp with time zone,
    last_subject character varying,
    is_read_by_1 boolean,
    is_read_by_2 boolean,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.chat_threads OWNER TO venrides_user;

--
-- Name: chat_threads_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.chat_threads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chat_threads_id_seq OWNER TO venrides_user;

--
-- Name: chat_threads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.chat_threads_id_seq OWNED BY public.chat_threads.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying,
    layout_type character varying,
    primary_color character varying,
    secondary_color character varying,
    accent_color character varying,
    logo_url character varying,
    filler_keywords character varying,
    google_drive_link character varying,
    priority_content_url character varying,
    sidebar_content json,
    bottom_bar_content json,
    pause_duration integer,
    is_active boolean DEFAULT true,
    max_screens integer,
    valid_until timestamp with time zone,
    rif character varying,
    address character varying,
    phone character varying,
    contact_person character varying,
    email character varying,
    client_editable_fields character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    design_settings json DEFAULT '{}'::json,
    video_source character varying DEFAULT 'youtube'::character varying,
    plan character varying DEFAULT 'free'::character varying,
    can_edit_profile boolean DEFAULT false,
    has_edited_profile boolean DEFAULT false,
    sidebar_header_type character varying DEFAULT 'text'::character varying,
    sidebar_header_value character varying,
    video_playlist json DEFAULT '[]'::json,
    ad_frequency integer DEFAULT 30,
    role character varying DEFAULT 'standard'::character varying
);


ALTER TABLE public.companies OWNER TO venrides_user;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO venrides_user;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    uuid character varying,
    name character varying,
    company_id integer,
    last_ping timestamp with time zone DEFAULT now()
);


ALTER TABLE public.devices OWNER TO venrides_user;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devices_id_seq OWNER TO venrides_user;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.email_templates (
    id integer NOT NULL,
    name character varying,
    subject character varying,
    body character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.email_templates OWNER TO venrides_user;

--
-- Name: email_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.email_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_templates_id_seq OWNER TO venrides_user;

--
-- Name: email_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.email_templates_id_seq OWNED BY public.email_templates.id;


--
-- Name: global_ads; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.global_ads (
    id integer NOT NULL,
    video_url character varying,
    ticker_text character varying,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.global_ads OWNER TO venrides_user;

--
-- Name: global_ads_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.global_ads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.global_ads_id_seq OWNER TO venrides_user;

--
-- Name: global_ads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.global_ads_id_seq OWNED BY public.global_ads.id;


--
-- Name: menus; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.menus (
    id integer NOT NULL,
    company_id integer,
    name character varying,
    price double precision,
    category character varying,
    is_available boolean
);


ALTER TABLE public.menus OWNER TO venrides_user;

--
-- Name: menus_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.menus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menus_id_seq OWNER TO venrides_user;

--
-- Name: menus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.menus_id_seq OWNED BY public.menus.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    sender_id integer,
    receiver_id integer,
    company_id integer,
    subject character varying,
    body character varying,
    attachment_url character varying,
    is_read boolean,
    created_at timestamp with time zone DEFAULT now(),
    is_alert boolean DEFAULT false,
    alert_duration integer DEFAULT 15
);


ALTER TABLE public.messages OWNER TO venrides_user;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO venrides_user;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    company_id integer,
    amount double precision,
    currency character varying,
    payment_method character varying,
    description character varying,
    payment_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.payments OWNER TO venrides_user;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO venrides_user;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: registration_codes; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.registration_codes (
    id integer NOT NULL,
    code character varying,
    company_id integer,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.registration_codes OWNER TO venrides_user;

--
-- Name: registration_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.registration_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.registration_codes_id_seq OWNER TO venrides_user;

--
-- Name: registration_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.registration_codes_id_seq OWNED BY public.registration_codes.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: venrides_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    company_id integer,
    username character varying,
    hashed_password character varying,
    is_admin boolean,
    role character varying DEFAULT 'operador_empresa'::character varying,
    permissions json DEFAULT '{}'::json,
    temp_password character varying,
    must_change_password boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO venrides_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: venrides_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO venrides_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: venrides_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: chat_threads id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.chat_threads ALTER COLUMN id SET DEFAULT nextval('public.chat_threads_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: email_templates id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.email_templates ALTER COLUMN id SET DEFAULT nextval('public.email_templates_id_seq'::regclass);


--
-- Name: global_ads id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.global_ads ALTER COLUMN id SET DEFAULT nextval('public.global_ads_id_seq'::regclass);


--
-- Name: menus id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.menus ALTER COLUMN id SET DEFAULT nextval('public.menus_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: registration_codes id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.registration_codes ALTER COLUMN id SET DEFAULT nextval('public.registration_codes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: chat_threads; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.chat_threads (id, gmail_thread_id, participant_1_id, participant_2_id, last_message_at, last_subject, is_read_by_1, is_read_by_2, created_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.companies (id, name, layout_type, primary_color, secondary_color, accent_color, logo_url, filler_keywords, google_drive_link, priority_content_url, sidebar_content, bottom_bar_content, pause_duration, is_active, max_screens, valid_until, rif, address, phone, contact_person, email, client_editable_fields, created_at, updated_at, design_settings, video_source, plan, can_edit_profile, has_edited_profile, sidebar_header_type, sidebar_header_value, video_playlist, ad_frequency, role) FROM stdin;
106	Final Verified Company	layout-a	#1a202c	#2d3748	#4a5568	\N	nature, food			[]	{"static": "Nuestra Mision es Servirle Bien", "whatsapp": "04xx-xxxxxxx", "instagram": "@nnnnnnnnn"}	10	t	2	\N	\N	\N	\N	\N	\N	name,layout_type,logo_url,sidebar_content,bottom_bar_content,pause_duration	2026-01-26 19:54:08.599198+00	2026-01-26 20:29:51.546107+00	{"name_font": "inherit", "name_color": "#ffffff", "name_size": "1.2rem", "name_weight": "bold", "sidebar_bg": null, "sidebar_text": null, "bottom_bar_bg": null, "bottom_bar_text": null, "ticker_speed": 30, "bcv_color": null, "bcv_size": null, "bcv_weight": null, "logo_auto_fit": true, "logo_size": 85, "sidebar_bg_image": null, "sidebar_effect": "none", "sidebar_width": 22, "bottom_bar_height": 10, "show_bcv": true}	youtube	free	f	f	text	\N	[]	30	standard
59	VenridesCafe	layout-a	#fefefe	#851316	#fef8f9	/logos/59_logo.jpeg	https://youtu.be/0CRdlQO68C4?si=DxS2gZ25sSQ_Trxj	https://www.youtube.com/watch?v=Pnbu8_rG08Y	\N	[{"items": [{"type": "text", "value": "Promoci\\u00f3n 11", "font_size": "1.4rem", "color": "#ffffff", "weight": "bold", "font_family": "Inter"}], "duration": 10}]	{"static": "fvnxfsffjykjuklflgl  fuyukdyj hkyfulruilum ", "whatsapp": "etet", "instagram": "rtyyyuetu", "font_size": "1.5rem", "color": "#fbbf24", "social_color": "#fbbf24"}	10	t	5	2027-01-21 02:38:22.098052+00	\N	\N	\N	\N	\N		2026-01-21 02:38:22.092899+00	2026-01-25 06:08:15.807051+00	{"name_font": "inherit", "sidebar_bg": "#ffffff", "sidebar_text": "#050505", "bottom_bar_bg": "#000000", "ticker_speed": 30, "bcv_weight": "bold", "logo_auto_fit": false, "logo_size": 80, "sidebar_effect": "glass_3d"}	youtube	free	f	f	text	\N	["https://youtu.be/0CRdlQO68C4?si=DxS2gZ25sSQ_Trxj"]	30	standard
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.devices (id, uuid, name, company_id, last_ping) FROM stdin;
2	8a4d1486-1524-4755-a458-af130c43e109	TV-8a4d1486	59	2026-01-23 02:18:21.279495+00
3	af7bf3b2-860a-4571-8e21-03093cedeb5a	TV-af7bf3b2	59	2026-01-23 03:11:47.059026+00
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.email_templates (id, name, subject, body, created_at) FROM stdin;
\.


--
-- Data for Name: global_ads; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.global_ads (id, video_url, ticker_text, updated_at) FROM stdin;
\.


--
-- Data for Name: menus; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.menus (id, company_id, name, price, category, is_available) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.messages (id, sender_id, receiver_id, company_id, subject, body, attachment_url, is_read, created_at, is_alert, alert_duration) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.payments (id, company_id, amount, currency, payment_method, description, payment_date) FROM stdin;
\.


--
-- Data for Name: registration_codes; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.registration_codes (id, code, company_id, expires_at, created_at) FROM stdin;
9	104678	59	2026-01-25 22:03:00.086735+00	2026-01-25 21:53:00.044554+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: venrides_user
--

COPY public.users (id, company_id, username, hashed_password, is_admin, role, permissions, temp_password, must_change_password) FROM stdin;
60	106	verified@example.com	$argon2id$v=19$m=65536,t=3,p=4$LeU8J0TI+T8nJCTkPMe4lw$qnyzbEa4RT2T+bupip421RFU2HUzUFKyjoDbI2YMLnA	f	user_basic	{}	\N	f
2	59	nerdop@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$IARAiBGC0FoLQeh9T8m5Fw$RzLrnCsBQRKRefk5nhSxQwbpwROcZe7rsXomIzFLQ14	t	admin_master	{}	\N	f
\.


--
-- Name: chat_threads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.chat_threads_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.companies_id_seq', 106, true);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.devices_id_seq', 5, true);


--
-- Name: email_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.email_templates_id_seq', 1, false);


--
-- Name: global_ads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.global_ads_id_seq', 1, false);


--
-- Name: menus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.menus_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: registration_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.registration_codes_id_seq', 9, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: venrides_user
--

SELECT pg_catalog.setval('public.users_id_seq', 60, true);


--
-- Name: chat_threads chat_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_name_key; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_name_key UNIQUE (name);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: global_ads global_ads_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.global_ads
    ADD CONSTRAINT global_ads_pkey PRIMARY KEY (id);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: registration_codes registration_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.registration_codes
    ADD CONSTRAINT registration_codes_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_chat_threads_gmail_thread_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE UNIQUE INDEX ix_chat_threads_gmail_thread_id ON public.chat_threads USING btree (gmail_thread_id);


--
-- Name: ix_chat_threads_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_chat_threads_id ON public.chat_threads USING btree (id);


--
-- Name: ix_companies_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_companies_id ON public.companies USING btree (id);


--
-- Name: ix_companies_name; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_companies_name ON public.companies USING btree (name);


--
-- Name: ix_devices_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_devices_id ON public.devices USING btree (id);


--
-- Name: ix_devices_uuid; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE UNIQUE INDEX ix_devices_uuid ON public.devices USING btree (uuid);


--
-- Name: ix_email_templates_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_email_templates_id ON public.email_templates USING btree (id);


--
-- Name: ix_global_ads_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_global_ads_id ON public.global_ads USING btree (id);


--
-- Name: ix_menus_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_menus_id ON public.menus USING btree (id);


--
-- Name: ix_messages_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_messages_id ON public.messages USING btree (id);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_registration_codes_code; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE UNIQUE INDEX ix_registration_codes_code ON public.registration_codes USING btree (code);


--
-- Name: ix_registration_codes_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_registration_codes_id ON public.registration_codes USING btree (id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: venrides_user
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: chat_threads chat_threads_participant_1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_participant_1_id_fkey FOREIGN KEY (participant_1_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_threads chat_threads_participant_2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_participant_2_id_fkey FOREIGN KEY (participant_2_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: devices devices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: menus menus_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: messages messages_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: messages messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: registration_codes registration_codes_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.registration_codes
    ADD CONSTRAINT registration_codes_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: users users_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: venrides_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: venrides_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict UZ76bgufxMXsamTvSsPoafwB6XujW12gY8kkFaUCl1pB0Skml2zAioNIVTmkW5R

