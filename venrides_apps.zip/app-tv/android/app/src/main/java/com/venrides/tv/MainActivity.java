package com.venrides.tv;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
